package pdb

var a string
